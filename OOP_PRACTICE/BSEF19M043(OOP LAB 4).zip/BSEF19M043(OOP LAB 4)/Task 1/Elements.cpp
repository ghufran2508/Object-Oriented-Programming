#include "Elements.h"	//including header file
int Element::size = 0;	//initializing static variables
int Element::alpha = 0;
int Element::beta = 0;

void Element::setVal(int ID, int alpha, int beta)	
{
	this->ID = ID;	//using this pointer 
	this->alpha = alpha;
	this->beta = beta;
}

void Element::setPointer()	//setting pointer
{
	(alpha == 1) ? ptr = &this->alpha : ptr = &this->beta;
}
//getting relevant functions
int Element::getSize()	
{
	return size;
}

int Element::getID()
{
	return this->ID;
}

int Element::getAlpha()
{
	return this->alpha;
}

int Element::getBeta()
{
	return this->beta;
}

void Element::printPointerAddress(Element e)
{
	cout << this->ptr;
}

