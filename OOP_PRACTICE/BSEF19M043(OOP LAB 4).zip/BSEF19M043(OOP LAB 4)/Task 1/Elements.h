#pragma once
#include<iostream>

using namespace std;

class Element	//making class
{
	int ID;	//declaring attributes
	static int size, alpha, beta;
	int* ptr;
public:
	Element()	//default constructor
	{
		ID = 0;	//initializing attributes
		ptr = nullptr;
		size++;
	}
	void setVal(int ID, int alpha, int beta);	//function prototypes
	void setPointer();
	static int getSize();
	int getID();
	int getAlpha();
	int getBeta();
	void printPointerAddress(Element e);
};
