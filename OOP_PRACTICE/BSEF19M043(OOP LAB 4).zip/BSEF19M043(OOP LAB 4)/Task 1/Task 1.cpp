#include"Elements.h"	//including header file

int main()
{
	int size, * id, * point, alpha, beta;	//declaring relevant variables
	cout << "Enter the number of elements: ";
	cin >> size;
	id = new int[size];
	Element* ele = new Element[size];	//dynamic object array
	for (int i = 0; i < size; i++)
	{
		cout << "Enter the ID of Element " << i + 1 << ": ";
		cin >> id[i];	//taking input from user
		(i % 2 == 0) ? ele[i].setVal(id[i], 1, 0) : ele[i].setVal(id[i], 0, 1);
	}
	alpha = ele->getAlpha();
	beta = ele->getBeta();
	cout << "\nAlpha: " << &alpha << endl;
	cout << "Beta: " << &beta << endl;
	for (int i = 0; i < size; i++)
	{
		cout << "Element# " << i+1 << endl;	//printing the required output
		cout << "ID: " << ele[i].getID() << endl;
		ele[i].setPointer();	//setting pointer
		cout << "Pointer Address: ";
		ele->printPointerAddress(ele[i]);	//pointer output
		cout << "\nSize: " <<  size << endl;
	}
	return 0;
}