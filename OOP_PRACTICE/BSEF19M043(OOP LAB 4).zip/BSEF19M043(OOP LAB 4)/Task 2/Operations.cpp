#include "Operations.h"

void Rational::set(int p, int q)	//checking if p and q are zero
{
	if (p == 0)
		p = 1;
	this->p = p;
	if (q == 0)
		q = 1;
	this->q = q;
}

void Rational::show() const	//output value of objects
{
	cout << "\nFirst number is: " << this->p << endl;
	cout << "Second number is: " << this->q << endl;
}

void Rational::simplify()	//simplifying
{
	if (p > q)
	{
		for (int i = 2; i < p; i++)
		{
			if (p % i == 0 && q % i == 0)
			{
				p /= i;
				q /= i;
			}
		}
	}
	else
	{
		for (int i = 2; i < q; i++)
		{
			if (p % i == 0 && q % i == 0)
			{
				p /= i;
				q /= i;
			}
		}
	}
	cout << "\nFirst simplified number: " << p<< endl;
	cout << "Second simplified number: " << q<< endl;
}

Rational Rational::add(Rational& r)	//adding functions
{
	int n1, n2;
	n1 = this->p + r.p;
	n2 = this->q + r.q;
	Rational temp(n1,n2);
	return temp;
}

Rational Rational::subtract(Rational& r)	//suntracting function
{
	int n1, n2;
	n1 = this->p - r.p;
	n2 = this->q - r.q;
	Rational temp(n1, n2);
	return temp;
}

Rational Rational::mul(Rational& r)	//multiplying functions
{
	int n1, n2;
	n1 = this->p * r.p;
	n2 = this->q * r.q;
	Rational temp(n1, n2);
	return temp;
}
