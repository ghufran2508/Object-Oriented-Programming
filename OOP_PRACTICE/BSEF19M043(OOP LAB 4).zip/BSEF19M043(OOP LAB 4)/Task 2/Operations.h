#pragma once
#include<iostream>

using namespace std;

class Rational
{
	int p, q;
public:
	Rational()
	{
		this->p = 0;
		this->q = 0;
	}
	Rational(int p, int q)//call set
	{
		this->p = p;
		this->q = q;
	}
	void set(int, int); //check q if equal to 0 then set 1, otherwise pass value to q
	void show() const;
	void simplify();//divide p & q by common divisor (if any), repeat till p & q has no common divisor
	Rational add(Rational& r);//add 2 rational numbers and return result in 3rd rational number
	Rational subtract(Rational& r);//Subtract and return result in 3rd rational number
	Rational mul(Rational& r);//multiply 2 rational numbers and return result in 3rd rational number
};
