#include"Operations.h"

int main()
{	
	int num1, num2, num3, num4;	//declaring variables
	cout << ":First Rational Number:" << endl;	//first rational number
	cout << "Enter first number: ";	
	cin >> num1;
	cout << "Enter second number: ";
	cin >> num2;
	Rational obj1(num1,num2);	//input in obj1
	cout << ":Second Rational Number:" << endl;	//Second rational number
	cout << "Enter first number: ";
	cin >> num3;
	cout << "Enter second number: ";
	cin >> num4;
	Rational obj2(num3, num4);	//input in obj2
	obj1.set(num1, num2);	//calling functions
	obj1.show();
	obj1.simplify();
	obj2.set(num3, num4);
	obj2.show();
	obj2.simplify();
	Rational obj3= obj1.add(obj2);	//adding obj1 and obj 2
	cout << "\nAfter adding Rational 1 and Rational 2: " << endl;
	obj3.show();
	obj3 = obj1.subtract(obj2);	//subtracting obj1 and obj 2
	cout << "\nAfter sutracting Rational 1 and Rational 2: " << endl;
	obj3.show();
	obj3 = obj1.mul(obj2);	//Multiplying obj1 and obj 2
	cout << "\nAfter Multiplying Rational 1 and Rational 2: " << endl;
	obj3.show();
	return 0;
}