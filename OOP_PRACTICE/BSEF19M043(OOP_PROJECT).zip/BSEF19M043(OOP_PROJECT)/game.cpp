#include "game.h"

SpaceShip::SpaceShip()
{
	xloc = 0;
	yloc = 0;

}

int SpaceShip::getxloc()
{
	return this->xloc;
}

int SpaceShip::getyloc()
{
	return this->yloc;
}


