#pragma once
#include<iostream>
#include<fstream>
using namespace std;

int sizeOfFile()
{
	ifstream in_file("a.txt", ios::binary);
	in_file.seekg(0, ios::end);
	int file_size = in_file.tellg();
	cout << "Size of the file in bytes is: ";
	return file_size;
}
