#include"FindSize.h"

int main() {
	cout << sizeOfFile();
}