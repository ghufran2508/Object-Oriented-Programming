#pragma once


#include<iostream>
#include<fstream>
#include<string>
using namespace std;
	string lowerCase(string str)
	{
		for (int i = 0; i < str.length(); i++)
		{
			if (str[i] >= 'A' && str[i] <= 'Z')		
			{
				str[i] += 32;
			}
		}
		return str;
	}

	bool countDuplicateA(string str) 
		{
			int counter = 0;
			for (int i = 0; i < str.length(); i++) 
			{
				if (str[i] == 'a') 
				{
					counter++;
				}
			}
		if (counter >= 2) 
		{
			return true;
		}
		return false;
	}
void AlphabetOperation()
{

	ifstream inFile;
	string temp;
	inFile.open("dictionary.txt");
	int count_words = 0;
	while (!inFile.eof()) 
	{
		getline(inFile, temp);
		count_words++;
	}
	inFile.close();

	inFile.open("dictionary.txt");
	string str;
	int wordsWithDoubleA = 0;
	int wordsWithStarting[26] = {};
	int firstLetter = 97, secondLetter = 97;
	int* code = new int[count_words];
	int index = 0;
	int wordsWithSameCode = 0;

	while (!inFile.eof()) 
	{
		firstLetter = secondLetter = 97;
		getline(inFile, str);

		temp = lowerCase(str);

		if (countDuplicateA(temp)) 
		{
			wordsWithDoubleA++;
		}

		wordsWithStarting[temp[0] - 'a']++;

		temp = str;

		if (temp.length() == 5) 
		{
			for (int i = 0; i < temp.length(); i++) 
			{
				firstLetter = (int)temp[i] - firstLetter;
				secondLetter += (int)temp[i];
			}
				if (index < count_words) 
				{
					code[index++] = (firstLetter * 10000) + (secondLetter * 1000) + ((int)temp[2] * 100) + ((int)temp[3] * 10) + (int)temp[4];
				}
			if (index > 0) 
			{
				for (int i = 0; i < index - 1; i++) 
				{
					if (code[index - 1] == code[i])		
					{
						wordsWithSameCode++;
						break;
					}
				}
			}
		}
	}

	cout << "Total number of words with double A/a are = " << wordsWithDoubleA << '\n';
	for (int i = 0; i < 26; i++) {
		cout << "Words starting with letter " << char(i + 97) << " are = " << wordsWithStarting[i] << '\n';
	}
	cout << "Words with unique code are = " << count_words - wordsWithSameCode << '\n';

	delete[] code;
	code = nullptr;

	inFile.close();
}