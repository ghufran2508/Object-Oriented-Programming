#include"OperationsOnAlphabets.h"

int main() 
	{
		AlphabetOperation();

		return 0;
	}