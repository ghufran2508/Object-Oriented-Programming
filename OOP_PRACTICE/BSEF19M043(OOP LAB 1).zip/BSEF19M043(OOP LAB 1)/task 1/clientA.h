#pragma once
#include<iostream>
using namespace std;

double Add(double a, double b)
{
	return a + b;
}
double Subtract(double a, double b)
{
	return a - b;
}
double Divide(double a, double b)
{
	return a / b;
}
double Multiply(double a, double b)
{
	return a * b;
}
double takeMod(int a, int b)
{
	return a % b;
}
double takePower(double a, double b)
{
	return pow(a, b);
}
double takeSquareRoot(double a)
{
	return sqrt(a);
}