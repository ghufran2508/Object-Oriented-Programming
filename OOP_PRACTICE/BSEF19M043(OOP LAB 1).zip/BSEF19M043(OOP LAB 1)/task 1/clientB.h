#pragma once

#include<cmath>

double takeSin(double a)
{
	return sin(a);
}
double takecos(double a)
{
	return cos(a);
}
double taketan(double a)
{
	return tan(a);
}