#pragma once

void removeRepElements(int arr[],int temp[], int N)
{

   
    for (int i = 0; i < N - 1; i++)
    {
        if (temp[i] != temp[i + 1])
        {
            temp[i] = arr[i];
        }

    }
       
}