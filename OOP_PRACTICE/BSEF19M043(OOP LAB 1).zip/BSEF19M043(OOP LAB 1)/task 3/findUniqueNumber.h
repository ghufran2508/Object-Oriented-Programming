#pragma once


#include<iostream>
using namespace std;

void uniqueNum(int* arr, int N)
{
	int count = 0;
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			if (i != j)
			{
				if (arr[i] == arr[j])
				{
					count++;
				}
			}
		}
	}
	cout << "The Number of Unique Elements is =" << N - count;
}
