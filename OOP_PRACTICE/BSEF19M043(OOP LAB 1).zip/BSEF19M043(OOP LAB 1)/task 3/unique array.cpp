#include"findUniqueNumber.h"
#include"RemoveRepetitiveElements.h"


int main()
{
    int N, * arr, * temp;
    cout << "\nEnter size of array:";
    cin >> N;
    arr = new int[N];
    temp = new int[N];
    for (int i = 0; i < N; i++)
    {
        arr[i] = rand() % 100;
    }
    for (int i = 0; i < N; i++)
    {
        temp[i] = arr[i];
    }
    cout << "\nElements of array are:-" << endl;
    for (int i = 0; i < N; i++)
    {
        cout << arr[i]<<endl;
    }  
    uniqueNum(arr, N);
    removeRepElements(arr,temp, N);
    cout << "\nArray without repetitive elements is:-" << endl;
    for (int i = 0; i < N; i++)
    {
        cout << arr[i] << endl;
    }
        

    return 0;
}