#include"Link_array.h"

int main()
{
    int** A[4] = {0};
    int* B[4] = {0};
    point( A, B);
       
    return 0;
}

