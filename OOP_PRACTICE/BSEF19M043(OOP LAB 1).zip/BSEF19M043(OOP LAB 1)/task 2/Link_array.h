#pragma once



void point(int **A[], int *B[]);