#include<iostream>
using namespace std;
void point(int** A[], int* B[])
{
	for (int i = 0; i < 4; i++)
	{
		if (i % 2 == 0)
		{
			A[i] = &B[i + 1];
		}
		else
		{
			A[i] = &B[i - 1];
		}
	}
	cout << "Adresses of pointer array A:-" << endl;
	for (int i = 0; i < 4; i++)
	{
		cout << A[i] << endl;
	}
	cout << "Adresses of pointer array B:-" << endl;
	for (int i = 0; i < 4; i++)
	{
		cout << B[i] << endl;
	}
}