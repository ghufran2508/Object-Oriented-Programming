#include <iostream>

using namespace std;

class Team //making class
{
    int scr1, wck1, scr2, wck2, scr3, wck3; //declaring variable
public:
    Team() //default constructor
    {
        scr3 = 0;
        wck3 = 0;
    }
    Team(int i, int j)   //parameterized constructor
    {
        cout << "****Team 4(parameterized)****" << endl;
        cout << "Team 4 has score: " << i << " and number of wickets: " << j << endl;
    }
    void setTeam1(int i, int j)   //setting values for team 1
    {
        scr1 = i;
        wck1 = j;
    }
    void getTeam1()   //getting values for team 1
    {
        cout << "Team 1 has score: " << scr1 << " and number of wickets: " << wck1 << endl;
    }
    void setTeam2(int i, int j)   //setting values for team 2
    {
        scr2 = i;
        wck2 = j;
    }
    void getTeam2() //getting values for team 2
    {
        cout << "Team 2 has score: " << scr2 << " and number of wickets: " << wck2 << endl;
    }
    void setTeam3(int i, int j)  //setting value for team 3
    {
        scr3 = i;
        scr3 = j;
    }
    void getTeam3() //getting values for team 3
    {
        cout << "Team 3 has score: " << scr3 << " and number of wickets: " << wck3 << endl;
    }

};

int main()
{
    Team cricket; //making object
    int scr1, scr2, wck1, wck2, scr3, wck3;
    cout << "****Enter data for team 1****" << endl;
    cout << "Enter Score :";
    cin >> scr1;
    cout << "Enter Number of wickets: ";
    cin >> wck1;
    cout << "****Enter data for team 2****" << endl;
    cout << "Enter Score :";
    cin >> scr2;
    cout << "Enter Number of wickets: ";
    cin >> wck2;
    cout << "****Enter data for team 3(default)****" << endl;
    cout << "Enter Score :";
    cin >> scr3;
    cout << "Enter Number of wickets: ";
    cin >> wck3;
    cricket.setTeam1(scr1, wck1); //calling relevant functions
    cricket.getTeam1();
    cricket.setTeam2(scr2, wck2);
    cricket.getTeam2();
    cricket.setTeam3(scr3, wck3);
    cricket.getTeam3();

    Team team4(11, 7);  //calling parameterized constructor
    if (scr1 > scr2 && scr1 > 11)   //applying conditions according to question
        cout << "Team 1 has highest score" << endl;
    if (scr2 > scr1 && scr2 > 11)
        cout << "Team 2 has highest score" << endl;
    if (scr1 < scr2 && scr1 < 11)
        cout << "Team 1 has minimum score" << endl;
    if (scr2 < scr1 && scr2 < 11)
        cout << "Team 2 has minimum score" << endl;
    if (11 < scr1 && 11 < scr2)
        cout << "Team 4 has minimum score" << endl;
    if (wck1 > 6)
        cout << "Team 1 has greater than 6 wickets. " << endl;
    if (wck2 > 6)
        cout << "Team 2 has greater than 6 wickets. " << endl;
    if (wck3 > 6)
        cout << "Team 3 has greater than 6 wickets. " << endl;
    if (7 > 6)
        cout << "Team 4 has greater than 6 wickets. " << endl;


    return 0;
}


