#include <iostream>
#define PI 3.14

using namespace std;

class Circle //making class
{
	int rad; 
	int originX, originY;
public:
	int findArea(int r) //function for finding area
	{
		return PI * r * r;
	}
	int findCircumference(int r)  //function for finding circumference
	{
		return 2 * PI * r;
	}
	int findDiameter(int r)  //function for finding diameter
	{
		return r * 2;
	}
	Circle(int r = 0, int originX = 0, int originY = 0)  //parameterized constructor 
	{
		this->rad = r;
		this->originX = originX;
		this->originY = originY;
	}
	int getOriginX() //getting origin x coordinate
	{
		return originX;
	}
	int getOriginY()  //getting origin y coordinate
	{
		return originY;
	}
	int getRadius()   //getting radius of circles
	{
		return rad;
	}

};

int main()
{
	Circle cir1(6, 56, 23);  //making relevant objects
	Circle cir2(7, 56, 23);
	Circle cir3(3, 65, 54);
	Circle cir4(9,43,52);


	int rad;
	cout << "Enter radius of the circle: ";
	cin >> rad;
	cout << "The area of circle is: " << cir1.findArea(rad) << endl;  //using relevant functions to get desired output
	cout << "The circumference of circle is: " << cir1.findCircumference(rad) << endl;
	cout << "The diameter of circle is: " << cir1.findDiameter(rad) << endl;
	if (cir1.getOriginX() == cir2.getOriginX() && cir1.getOriginY() == cir2.getOriginY())  //applying conditions to find cocentric circles and also labeling them
	{
		cout << "\nCircle 1 and 2 are cocentric" << endl;
		if (cir1.getRadius() > cir2.getRadius())
			cout << "\nCircle 1 has Label 2 and Circle 2 has Label 1" << endl;
		else
			cout << "\nCircle 1 has Label 1 and Circle 2 has Label 2" << endl;
		if (cir1.findDiameter(rad) > 12)
			cout << "Circle 1 has radius greater than 12" << endl;
		if (cir2.findDiameter(rad) > 12)
			cout << "Circle 2 has radius greater than 12" << endl;
	}
	if (cir2.getOriginX() == cir3.getOriginX() && cir2.getOriginY() == cir3.getOriginY())
	{
		cout << "Circle 2 and 3 are cocentric" << endl;
		if (cir2.getRadius() > cir3.getRadius())
			cout << "\nCircle 2 has Label 2 and Circle 3 has Label 1" << endl;
		else
			cout << "\nCircle 2 has Label 1 and Circle 3 has Label 2" << endl;
		if (cir2.findDiameter(rad) > 12)
			cout << "Circle 2 has radius greater than 12" << endl;
		if (cir3.findDiameter(rad) > 12)
			cout << "Circle 3 has radius greater than 12" << endl;
	}
	if (cir3.getOriginX() == cir4.getOriginX() && cir3.getOriginY() == cir4.getOriginY())
	{
		cout << "Circle 3 and 4 are cocentric" << endl;
		if (cir3.getRadius() > cir4.getRadius())
			cout << "\nCircle 3 has Label 2 and Circle 4 has Label 1" << endl;
		else
			cout << "\nCircle 3 has Label 1 and Circle 4 has Label 2" << endl;
		if (cir3.findDiameter(rad) > 12)
			cout << "Circle 3 has radius greater than 12" << endl;
		if (cir4.findDiameter(rad) > 12)
			cout << "Circle 4 has radius greater than 12" << endl;
	}
	if (cir1.getOriginX() == cir4.getOriginX() && cir1.getOriginY() == cir4.getOriginY())
	{
		cout << "Circle 1 and 4 are cocentric" << endl;
		if (cir1.getRadius() > cir4.getRadius())
			cout << "\nCircle 1 has Label 2 and Circle 4 has Label 1" << endl;
		else
			cout << "\nCircle 1 has Label 1 and Circle 4 has Label 2" << endl;
		if (cir1.findDiameter(rad) > 12)
			cout << "Circle 1 has radius greater than 12" << endl;
		if (cir4.findDiameter(rad) > 12)
			cout << "Circle 4 has radius greater than 12" << endl;
	}
	if (cir2.getOriginX() == cir4.getOriginX() && cir2.getOriginY() == cir4.getOriginY())
	{
		cout << "Circle 2 and 4 are cocentric" << endl;
		if (cir2.getRadius() > cir4.getRadius())
			cout << "\nCircle 2 has Label 2 and Circle 4 has Label 1" << endl;
		else
			cout << "\nCircle 2 has Label 1 and Circle 4 has Label 2" << endl;
		if (cir2.findDiameter(rad) > 12)
			cout << "Circle 2 has radius greater than 12" << endl;
		if (cir4.findDiameter(rad) > 12)
			cout << "Circle 4 has radius greater than 12" << endl;
	}
	return 0;
}