#include<iostream>

using namespace std;

class Job  //making class
{
	int deadline;
public:
	Job(int x = 0)  //parameterized constructor 
	{		
		this->deadline = x;
	}
	int getDeadline()  //getting deadlines
	{
		return deadline;
	}


};

int main()
{
	int num1,num2;  //initializing variables to compare deadline
	Job deadline1(5);  //making relevant objects
	num1=deadline1.getDeadline();
	Job deadline2(12);
	num2 = deadline2.getDeadline();
	Job deadline3(6);  //applying conditional operator to find earliest
	(deadline3.getDeadline() < num1) ? num1 = deadline3.getDeadline() : (deadline3.getDeadline() < num2) ? num2 = deadline3.getDeadline() : 1;		
	Job deadline4(8);
	(deadline4.getDeadline() < num1) ? num1 = deadline4.getDeadline() : (deadline4.getDeadline() < num2) ? num2 = deadline4.getDeadline() : 1;
	Job deadline5(1);
	(deadline5.getDeadline() < num1) ? num1 = deadline5.getDeadline() : (deadline5.getDeadline() < num2) ? num2 = deadline5.getDeadline() : 1;
	Job deadline6(14);
	(deadline6.getDeadline() < num1) ? num1 = deadline6.getDeadline() : (deadline6.getDeadline() < num2) ? num2 = deadline6.getDeadline() : 1;
	Job deadline7(18);
	(deadline7.getDeadline() < num1) ? num1 = deadline7.getDeadline() : (deadline7.getDeadline() < num2) ? num2 = deadline7.getDeadline() : 1;
	Job deadline8(23);
	(deadline8.getDeadline() < num1) ? num1 = deadline8.getDeadline() : (deadline8.getDeadline() < num2) ? num2 = deadline8.getDeadline() : 1;
	Job deadline9(7);
	(deadline9.getDeadline() < num1) ? num1 = deadline9.getDeadline() : (deadline9.getDeadline() < num2) ? num2 = deadline9.getDeadline() : 1;
	Job deadline10(3);
	(deadline10.getDeadline() < num1) ? num1 = deadline10.getDeadline() : (deadline10.getDeadline() < num2) ? num2 = deadline10.getDeadline() : 1;
	cout << "Job 1  has deadline: "<< deadline1.getDeadline()  << endl;  //outputting the required result
	cout << "Job 2  has deadline: " << deadline2.getDeadline() << endl;
	cout << "Job 3  has deadline: " << deadline3.getDeadline() << endl;
	cout << "Job 4  has deadline: " << deadline4.getDeadline() << endl;
	cout << "Job 5  has deadline: " << deadline5.getDeadline() << endl;
	cout << "Job 6  has deadline: " << deadline6.getDeadline() << endl;
	cout << "Job 7  has deadline: " << deadline7.getDeadline() << endl;
	cout << "Job 8  has deadline: " << deadline8.getDeadline() << endl;
	cout << "Job 9  has deadline: " << deadline9.getDeadline() << endl;
	cout << "Job 10 has deadline: " << deadline10.getDeadline() << endl;
	cout << "Jobs with deadline " << num1 << " and " << num2 << " are earliest." << endl;  //outputting the earliest jobs

	return 0;
}