#pragma once

#include<iostream>

using namespace std;

class ArmyOfficers
{
private:
	int id;
	int rank;
public:
	ArmyOfficers()	//default constructor
	{
		this->id = 0;
		this->rank = 0;
	}
	ArmyOfficers(int id, int rank)	//overloaded constructor
	{
		this->id = id;
		this->rank = rank;
	}
	void set(int id, int rank);	//setter
	int getID();	//ID getter
	int getRank();	//Rank getter
	ArmyOfficers getHighestRank(ArmyOfficers a);

};