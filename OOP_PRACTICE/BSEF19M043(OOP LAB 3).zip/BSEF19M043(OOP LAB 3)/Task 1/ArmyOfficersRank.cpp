#include "ArmyOfficersRank.h"

void ArmyOfficers::set(int id, int rank)
{
	this->id = id;
	this->rank = rank;
}

int ArmyOfficers::getID()
{
	return id;
}

int ArmyOfficers::getRank()
{
	return rank;
}

ArmyOfficers ArmyOfficers::getHighestRank(ArmyOfficers a)	//Comparing function
{
	ArmyOfficers temp;
	if (this->rank > a.getRank())
	{
		temp.set(id, rank);
	}
	else
	{
		temp.set(id, rank);
	}
	return temp;
}
