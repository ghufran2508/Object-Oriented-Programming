#include "ArmyOfficersRank.h"

int main()
{
	ArmyOfficers officer1;	//making object which also calls default constructor
	ArmyOfficers officer2(10, 4);	//calling parameterized constructor
	int id, rank;
	cout << "Enter the ID of army officer: ";
	cin >> id;
	cout << "Enter the rank: ";
	cin >> rank;
	officer1.set(id, rank); //setting values
	cout << "ID of army officer (hardcoded): " << officer2.getID() << endl;	//outputting hardcoded values
	cout << "Rank: " << officer2.getRank() << endl;
	
	ArmyOfficers officer3=officer1.getHighestRank(officer2);
	cout << "ID of highest Ranked officer: " << officer3.getID() << endl;
	cout << "Rank: " << officer3.getRank() << endl;
	

	return 0;
}