#include "ArrayOperation.h"		//including header file

void Bag20::Insert(int number)	//making function for input
{
	arr[size] = number;
	size++;
}

void Bag20::show()	//making function for displaying values
{
	for (int i = 0; i < size; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
}

int Bag20::elementAt(int index)	//defining function
{
	if (index > size)
	{
		cout << "Index goes out of bounds";
		return -1;
	}
	else
	{
		cout << "Value at index " << index << " : ";
		return arr[index];
	}
}

int Bag20::findFrequency(int freq)
{
	int counter = 0;
	for (int i = 0; i < size; i++)
	{
		if (arr[i] == freq)
		{
			counter++;
		}
	}
	return counter;
}

void Bag20::Delete(int del)	//deleting values as entered by user
{
	for (int i = 0; i < size; i++)
	{
		if (arr[i] == del)
		{
			DeleteByIndex(i);
		}
	}
}
void Bag20::DeleteByIndex(int index)
{
	if (index >= 0 && index < size)
	{		
		for (int i = index; i < size - 1; i++)
			arr[i] = arr[i + 1];
		size--;
	}
	
}

Bag20 Bag20::Union(Bag20 bag2)	//taking bag 1 and bag 2 union and making bag 3
{
	Bag20 temp;
	for (int i = 0; i < size; i++)
	{
		temp.Insert(arr[i]);
	}
	for (int i = 0; i < bag2.size; i++)
	{
		temp.Insert(bag2.arr[i]);
	}

	return temp;
}
int Bag20::findEquilibriumIndex(Bag20 bag3)	
{
	int sum1 = 0, sum2 = 0;
	if (bag3.size % 2 == 0)
	{
		return -1;
	}
	for (int i = 0; i < bag3.size / 2; i++)
	{
		sum1 = sum1 + bag3.arr[i];
	}
	for (int i = (bag3.size / 2) + 1; i < bag3.size; i++)
	{
		sum2 = sum2 + bag3.arr[i];
	}
	if (sum1 == sum2)
	{
		return arr[(bag3.size / 2)];
	}
	else
	{
		return -1;
	}
}

Bag20 Bag20::leftRotate(Bag20 bag3, int num)	//making function to rotate and making bag 4
{
	Bag20 temp,bag4;
	int si;
	for (int i = num; i < bag3.size; i++)
	{
		temp.Insert(bag3.arr[i]);
	}
	for (int i = 0; i < num; i++)
	{
		temp.Insert(bag3.arr[i]);
	}
	si = temp.size + size;
	
	for (int i = 0; i < temp.size; i++)
	{
		bag4.Insert((i<size)?arr [i]:0);	
		bag4.Insert(temp.arr[i]);		
	}

	return bag4;
}
	