#include "ArrayOperation.h"

int main()
{
	Bag20 bag1, bag2;	//making objects
	int num, index, frequency, del, factor;	//declaring variables
	cout << "****Enter the elements for two bags****" << endl;
	for (int i = 0; i < 20; i++)	//inserting values in object 1
	{
		cout << "Enter the value to insert in bag 1: ";
		cin >> num;
		if (num != -1)
		{
			bag1.Insert(num);
		}
		else
		{
			break;
		}
	}
	for (int i = 0; i < 20; i++)	//inserting values in object 2
	{
		cout << "Enter the value to insert in bag 2: ";
		cin >> num;
		if (num != -1)
		{
			bag2.Insert(num);
		}
		else
		{
			break;
		}
	}
	cout << "Contents of bag 1: ";
	bag1.show();	//displaying object 1 content
	cout << "Contents of bag 2: ";
	bag2.show();	//displaying object 1 content
	cout << "Enter the index at which value should be found in bag 1 array: ";
	cin >> index;
	(index > -1) ? cout << bag1.elementAt(index) : cout << "Index cannot be negative";	//making relevant conditions
	cout << "\nEnter the element whose frequency should be found in bag 1 array: ";	
	cin >> frequency;
	cout << "Frequency of " << frequency << " : " << bag1.findFrequency(frequency);	//calling desired functions
	cout << "\nEnter the element which should be removed from bag 1 array: ";
	cin >> del;
	cout << "Contents of bag 1 : ";
	bag1.Delete(del);
	bag1.show();	//displaying bag 1 value after deleting certain content
	cout << "\nUnion of bag 1 and bag 2 (bag 3):" << endl;
	Bag20 bag3 = bag1.Union(bag2);
	bag3.show();
	cout << "Equilibrium index of bag 3: " << bag3.findEquilibriumIndex(bag3);
	cout << "\nEnter the factor by which to rotate bag 3: " ;
	cin >> factor;
	Bag20 bag4 = bag1.leftRotate(bag3, factor);
	cout << "Contents of bag 1: ";
	bag1.show();
	cout << "Contents of bag 3: ";
	bag3.show();
	cout << "Contents of bag 4: ";
	bag4.show();


	return 0;
}