#pragma once

#include<iostream>

using namespace std;

class Bag20 //making class
{
private:	//declaring variable
	int arr[20];
	int size;
public:
	Bag20()	//initializing in default constructor
	{
		size = 0;
	}
	void Insert(int);	//relevant function prototypes
	void show();
	int elementAt(int);
	int findFrequency(int);
	void Delete(int);
	Bag20 Union(Bag20);
	void DeleteByIndex(int);
	int findEquilibriumIndex(Bag20);
	Bag20 leftRotate(Bag20, int);


};
