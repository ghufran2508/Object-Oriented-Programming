//BSEF19M043
//Abubakar Dar
#include<iostream>
#include<string>

using namespace std;

class Employee	//Parent class
{
	int id;
	string name;
	string desig;
public:
	Employee()	//default constructor
	{
		this->id = 0;
		this->name = "";
		this->desig = "";
	}
	void input(int id,string name,string desig)	//input function
	{
		this->id = id;
		this->name = name;
		this->desig = desig;
	}
	void display()	//display function
	{
		cout << "ID of employee: " << this->id << endl;
		cout << "Name of employee: " << this->name << endl;
		cout << "Designation of emplyee: " << this->desig << endl;
	}
};

class Salary :public Employee	//child class
{
	int basic_pay, human_resource_allowance, dearness_allowance, profitability_fund, net_pay;
public:
	Salary()
	{
		this->basic_pay = 0;
		this->human_resource_allowance = 0;
		this->dearness_allowance = 0;
		this->profitability_fund = 0;
		this->net_pay = 0;
	}
	void getEmployeeDetails(int basic_pay,int human_resource_allowance,int dearness_allowance,int profitability_fund, int id, string name, string desig)	//getter
	{
		this->basic_pay = basic_pay;
		this->human_resource_allowance = human_resource_allowance;
		this->dearness_allowance = dearness_allowance;
		this->profitability_fund = profitability_fund;
		net_pay = basic_pay + human_resource_allowance + dearness_allowance - profitability_fund;
		input(id,name,desig);
	}
	void display()	//display overridden
	{
		Employee::display();
		cout << "Basic pay: " << basic_pay << endl;
		cout << "Human resource allowance: " << human_resource_allowance << endl;
		cout << "Dearness allowance: " << dearness_allowance << endl;
		cout << "Profitability fund: " << profitability_fund << endl;
		cout << "Net pay: " << net_pay << endl;
	}
};

class BankCredit:public Salary	//grandchild class
{
	int acc_no;	//data members
	string bank_name;
public:
	BankCredit()	//default constructor
	{
		acc_no = 0;
		bank_name = "";
	}
	void getBankDetails(int acc_no,string bank_name, int basic_pay, int human_resource_allowance, int dearness_allowance, int profitability_fund, int id, string name, string desig)	//getter function
	{
		getEmployeeDetails(basic_pay, human_resource_allowance,dearness_allowance ,profitability_fund,id,name,desig);
		this->acc_no = acc_no;
		this->bank_name = bank_name;
	}
	void display()	//display overridder
	{
		Salary::display();
		cout << "Account number: " << this->acc_no << endl;
		cout << "Bank Name: " << this->bank_name << endl;
	}
};

int main()	//main function
{
	BankCredit acc[5];	//array of obj
	int emp,acc_no,basic_pay,hum_res_all,dear_all,profit_fund,id;	//relevant variables
	string bank_name, name, desig;
	cout << "Enter number of employees: ";	
	cin >> emp;

	for (int i = 0; i < emp; i++)	
	{
		cout << "****************Emplyee No." << i + 1<<"*************************"<<endl;	
		cout << "Enter employee name: ";
		cin >> name;
		cout << "Enter employee id: ";
		cin >> id;
		cout << "Enter employee designation: ";
		cin >> desig;
		cout << "Enter basic pay: ";
		cin >> basic_pay;
		cout << "Enter Human resource allownce: ";
		cin >> hum_res_all;
		cout << "Enter dearness allownce: ";
		cin >> dear_all;
		cout << "Enter Profitablity fund: ";
		cin >> profit_fund;
		cout << "Enter account number: ";
		cin >> acc_no;
		cout << "Enter bank name: ";
		cin >> bank_name;
		acc[i].getBankDetails(acc_no, bank_name, basic_pay, hum_res_all, dear_all, profit_fund, id,name,desig);	//function call
		acc[i].display();	//display function called
	}


	return 0;
}