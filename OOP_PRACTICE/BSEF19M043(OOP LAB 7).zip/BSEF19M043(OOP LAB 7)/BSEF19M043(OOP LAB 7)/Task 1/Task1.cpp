//BSEF19M043
//Abubakar Dar
#include<iostream>
#include<string>

using namespace std;

class Book	//Parent class Book
{
	string title;
	string author;
public:
	Book()	//default constructor
	{
		this->title = "";
		this->author = "";
	}
	void setTitle(string title)	//setter fucntion
	{
		this->title = title;
	}
	void setAuthor(string author)
	{
		this->author = author;
	}
	void show()	//display fucntion
	{
		cout << "\nTitle is: " << this->title << endl;
		cout << "Author is: " << this->author << endl;
	}
};
class Fiction :public Book	//child/sub class
{
	int level;	//data member
public:
	Fiction()	//default constructor
	{
		level = 0;
	}
	void setLevel(int level, string title, string author)	//setter
	{
		this->level = level;
		setTitle(title);
		setAuthor(author);		
	}
	void show()	//output fucntion
	{
		Book::show();
		cout << "Level is: " << level << endl;
	}
};

class NonFiction :public Book	//child/sub class
{
	int no_of_pages;	//data member
public:
	NonFiction()	//default constructor
	{
		no_of_pages = 0;
	}
	void setLevel(int no_of_pages, string title, string author)
	{
		this->no_of_pages = no_of_pages;
		setTitle(title);
		setAuthor(author);
	}
	void show()
	{
		Book::show();
		cout << "Number of pages are : " << no_of_pages << endl;
	}
};

int main()
{
	Fiction b1[5];	//array of objects
	NonFiction b2[5];	
	int level = 0, no_of_pages = 0;
	string title, author;
	cout << "*************Fiction Books**************" << endl;;
	for (int i = 0; i < 5; i++)
	{
		cout << "Enter title of book:";
		cin >> title;
		cout << "Enter author of book: ";
		cin >> author;
		cout << "Enter level of book: ";
		cin >> level;
		b1[i].setLevel(level, title, author);	//calling relevant fucntions
		b1[i].show();
	}
	cout << "**************Non-Fiction Books****************" << endl;
	for (int i = 0; i < 5; i++)
	{
		cout << "Enter title of book:";
		cin >> title;
		cout << "Enter author of book: ";
		cin >> author;
		cout << "Enter number of pages of book: ";
		cin >> no_of_pages;
		b2[i].setLevel(no_of_pages, title, author);
		b2[i].show();
	}
	return 0;
}