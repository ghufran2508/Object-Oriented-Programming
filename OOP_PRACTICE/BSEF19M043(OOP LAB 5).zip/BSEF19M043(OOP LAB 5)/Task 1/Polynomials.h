#pragma once
#include<iostream>	//including relevant library files

//Abubakar Dar
//BSEF19M043
using namespace std;	

class Polynomial	//making class
{
	int* coef;	//objects
	int degree;
public:
	Polynomial();	//default constructor
	Polynomial(const Polynomial& );	//copy constructor
	~Polynomial();	//destructor
	void setPoly(int, int, int);	//setter
	int getPoly(int);	//getter
	void Input();	
	void Display();
	void setDeg(int);
	int getDeg();
	void operator =(const Polynomial&);	//operators prototypes
	Polynomial operator +(const Polynomial&);
	void operator +=(const Polynomial&);
	Polynomial operator -(const Polynomial&);
	void operator -=(const Polynomial&);
	void operator ==(const Polynomial&);
	void operator >(const Polynomial&);
	void operator <(const Polynomial&);
};