#include"Polynomials.h"	//including relevant header file
//Abubakar Dar
//BSEF19M043


int main()
{
	Polynomial p1, p2,p3, p4;	//making objects
	
	p1.Input();	//input functions
	p2.Input();
	cout << "First Polynomial: ";
	p1.Display();	//display function
	cout << "Second Polynomial: ";
	p2.Display();
	p3 = p1;	//deep copy
	p4 = p1 + p2;		//operators
	cout << "\n+ operator: ";
	p4.Display();
	p1 += p2;
	cout << "\n+= operator: ";
	p1.Display();
	p4 = p1 - p2;
	cout << "\n- operator: ";
	p4.Display();
	p1 -= p2;
	cout << "\n-= operator: ";
	p1.Display();
	cout << "\n== operator: ";
	p1 == p2;	
	cout << "\n> operator: ";
	p1 > p2;
	cout << "\n< operator: ";
	p1 < p2;
	return 0;
}