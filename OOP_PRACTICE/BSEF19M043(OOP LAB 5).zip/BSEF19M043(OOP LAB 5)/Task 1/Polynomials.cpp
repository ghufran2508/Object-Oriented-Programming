#include "Polynomials.h"
//Abubakar Dar
//BSEF19M043
Polynomial::Polynomial()    //default constructor
{
    coef = new int[30];
    degree = 0;
    for (int i = 0; i < 30; i++)
    {
        coef[i] = 0;
    }
}
Polynomial::Polynomial(const Polynomial& temp)
{
    this->coef = new int[30];
    for (int i = 0; i < 30; i++)
    {
        this->coef[i] = temp.coef[i];

    }
    this->degree = temp.degree;

}
Polynomial::~Polynomial()   //destructor
{
    if (coef != nullptr)
    {
        delete[] coef;
        coef = nullptr;
    }

}
void Polynomial::setPoly(int val, int index, int degree)    //function definitions
{
    coef[index] = val;
}

void Polynomial::Input()
{
    int val;
    cout << "Enter the degree of polynomial: ";
    cin >> this->degree;
    for (int i = 0; i <= this->degree; i++)
    {
        cout << "Enter the value of Coefficient of x^" << i << ":";
        cin >> val;
        this->setPoly(val, i, this->degree);
    }
}

void Polynomial::Display()
{
    for (int i = this->degree; i >= 0; i--)
    {
        if (this->getPoly(i) != 0)
        {
            cout << showpos << this->getPoly(i) << "x^" << noshowpos << i;
        }
    }
    cout << endl;
    
}

void Polynomial::setDeg(int deg)
{
    this->degree=deg;
}

int Polynomial::getDeg()    
{
    return this->degree;
}

int Polynomial::getPoly(int index)
{
    return coef[index];
}

Polynomial Polynomial::operator+(const Polynomial& p2)
{
    Polynomial temp;
    temp.degree = (this->degree >= p2.degree) ? this->degree : p2.degree;
    
    for (int i = 0; i <= temp.degree ; i++)
    {        
        temp.setPoly(p2.coef[i] +  coef[i] , i, temp.degree);
        
    }  
    return temp;
}

void Polynomial::operator+=(const Polynomial& p2)
{
    this->degree = (this->degree >= p2.degree) ? this->degree : p2.degree;

    for (int i = 0; i <= this->degree; i++)
    {
        this->setPoly(p2.coef[i] + coef[i], i, this->degree);

    }
    
}

Polynomial Polynomial::operator-(const Polynomial& p2)
{
    Polynomial temp;
    temp.degree = (this->degree >= p2.degree) ? this->degree : p2.degree;

    for (int i = 0; i <= temp.degree; i++)
    {
        temp.setPoly(p2.coef[i] - coef[i], i, temp.degree);

    }
    return temp;
}

void Polynomial::operator-=(const Polynomial& p2)
{
    this->degree = (this->degree >= p2.degree) ? this->degree : p2.degree;

    for (int i = 0; i <= this->degree; i++)
    {
        this->setPoly(p2.coef[i] - coef[i], i, this->degree);

    }
}

void Polynomial::operator==(const Polynomial& p2)
{
    bool flag = false;
    this->degree = (this->degree >= p2.degree) ? this->degree : p2.degree;
    if (this->degree == p2.degree)
    {
        for (int i = 0; i <= this->degree; i++)
        {
            if (this->coef[i] != p2.coef[i])
            {
                flag = false;
            }
            else
            {
                flag = true;
            }
        }
        if (flag == true)
        {
            cout << "Polynomial 1 and 2 are equal";
        }
        else
        {
            cout << "Polynomial 1 and 2 are NOT equal";
        }
    }
    else
    {
        cout<< "Polynomial 1 and 2 are NOT equal";
    }
}

void Polynomial::operator>(const Polynomial& p2)
{
    if (this->degree > p2.degree)
    {
        cout << "Degree of Polynomial 1 is greater ";
    }
    else
    {
        cout << "Degree of Polynomial 2 is greater ";
    }
}

void Polynomial::operator<(const Polynomial& p2)
{
    if (this->degree < p2.degree)
    {
        cout << "Degree of Polynomial 1 is smaller ";
    }
    else
    {
        cout << "Degree of Polynomial 2 is smaller ";
    }
}

void Polynomial::operator=(const Polynomial& temp)
{
    this->coef = new int[30];
    for (int i = 0; i < 30; i++)
    {
        this->coef[i] = temp.coef[i];

    }
    this->degree = temp.degree;
    
}


